from django.contrib import admin
from apiapp.models import *
# Register your models here.


admin.site.register(WebsiteList)
admin.site.register(ReviewsAndRatting)
admin.site.register(CurrencyList)
admin.site.register(CurrentRate)